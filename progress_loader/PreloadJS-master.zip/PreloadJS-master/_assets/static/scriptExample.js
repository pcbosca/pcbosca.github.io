(function(){
	window.foo = true;
}())
